/*
 * Copyright LWJGL. All rights reserved.
 * License terms: http://lwjgl.org/license.php
 * MACHINE GENERATED FILE, DO NOT EDIT
 */
package org.lwjgl.openal;

/** bindings to AL_EXT_ALAW extension. */
public final class EXTAlaw {

	/** AL_EXT_ALAW tokens. */
	public static final int
		AL_FORMAT_MONO_ALAW_EXT   = 0x10016,
		AL_FORMAT_STEREO_ALAW_EXT = 0x10017;

	private EXTAlaw() {}

}